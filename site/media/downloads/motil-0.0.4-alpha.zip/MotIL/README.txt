Extract MotIL.swf from the archive and launch with standalone Flash Player to play offline.
